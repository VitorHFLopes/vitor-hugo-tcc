Nome do Arquivo:
log.txt

Par�metros:
1,2,3

Legenda:
1 - Armazena a quantidade do liquido verde
2 - Armazena a quantidade do liquido laranja
3 - Armazena a quantidade das garrafas utilizadas